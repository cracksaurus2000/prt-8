export const firebaseConfig = {
    apiKey: "AIzaSyC1w-zOXgJTiYqi5W1hKx0ep0RBV17eRjM",
    authDomain: "spectagram-42203.firebaseapp.com",
    databaseURL: "https://spectagram-42203-default-rtdb.firebaseio.com",
    projectId: "spectagram-42203",
    storageBucket: "spectagram-42203.appspot.com",
    messagingSenderId: "247871808696",
    appId: "1:247871808696:web:b3601c89ddd85d659dc04d"
  };